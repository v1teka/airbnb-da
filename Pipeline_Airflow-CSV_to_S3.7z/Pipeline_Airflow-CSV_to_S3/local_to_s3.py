from airflow import DAG
from datetime import datetime, timedelta
from airflow.operators import PythonOperator
from csv_upload_to_s3 import S3
import boto3


default_args = {
    'owner': 'Airflow',
    'start_date': datetime(2021, 3, 25),
    'retries': 1,
    'retry_delay': timedelta(seconds=5)
}

with DAG("UPLOAD_CSV_TO_S3",default_args = default_args, schedule_interval="@daily", catchup=False) as dag:
    t1=PythonOperator(task_id="csv_uploading", python_callable= S3)