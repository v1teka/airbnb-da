# import requests
# import csv
# import json
import boto3
from auth import ACCESS_KEY,SECRET_KEY

def S3():

    client=boto3.client('s3',aws_access_key_id = ACCESS_KEY, aws_secret_access_key = SECRET_KEY)

    client.create_bucket(Bucket='airbnb-data-hw2')
    with open("/usr/local/airflow/dags/airbnb-reviews.csv","rb") as f:
        client.upload_fileobj(f,"airbnb-data-hw2","airbnb-reviews.csv")

    print("Upload Completed")
